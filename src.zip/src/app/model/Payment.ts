export class Payment {
    paymentId:number;
    pId:number;
    consultationFee:number;
    cardNumber:number;
    cvv:number;
    cardHolderName:string;

    /* constructor(paymentId:number, pId:number,consultationFee:number,cardNumber:number, cvv:number,cardHolderName:string)
    {
        this.paymentId=paymentId;
        this.pId=pId;
        this.consultationFee=consultationFee;
        this.cardNumber=cardNumber;
        this.cvv=cvv;
        this.cardHolderName=cardHolderName;
    } */


}
