package com.example.demo.exceptions;


public class PatientDataAlreadyAvailableFoundException extends Exception{
		public PatientDataAlreadyAvailableFoundException(String message) {
			super(message);
		}
	}
