package com.example.demo.exceptions;

public class DoctorDataAlreadyAvailableFoundException extends Exception {
	public DoctorDataAlreadyAvailableFoundException(String message) {
		super(message);
	}
	

}
