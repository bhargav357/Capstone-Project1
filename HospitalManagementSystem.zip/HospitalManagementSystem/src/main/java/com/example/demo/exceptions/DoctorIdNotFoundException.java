package com.example.demo.exceptions;

public class DoctorIdNotFoundException extends Exception{
	public DoctorIdNotFoundException(String message) {
	super(message);
	}

}
