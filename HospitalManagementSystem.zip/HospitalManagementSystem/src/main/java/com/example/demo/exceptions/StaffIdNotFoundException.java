package com.example.demo.exceptions;

public class StaffIdNotFoundException extends Exception{
	public StaffIdNotFoundException(String message) {
		super(message);
	}
}

