package com.example.demo.exceptions;


public class PatientIdNotFoundException extends Exception{
	public PatientIdNotFoundException(String message) {
		super(message);
	}
}
