package com.example.demo.exceptions;


public class StaffDataAlreadyAvailableFoundException extends Exception{
	public StaffDataAlreadyAvailableFoundException(String message) {
		super(message);
	}
}
